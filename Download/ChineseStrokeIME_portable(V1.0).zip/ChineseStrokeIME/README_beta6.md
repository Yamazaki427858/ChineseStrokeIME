
# 中文筆劃輸入法

[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Platform](https://img.shields.io/badge/Platform-Windows-green.svg)](https://www.microsoft.com/windows)
[![Language](https://img.shields.io/badge/Language-C%2B%2B14-orange.svg)](https://isocpp.org/)
[![Version](https://img.shields.io/badge/Version-6.0-brightgreen.svg)](https://github.com/your-username/chinese-stroke-ime/releases)

## 📖 項目簡介

基於Windows API、採用C++14開發實現的中文筆劃輸入法。集成智慧學習算法、完全自訂介面配色和字碼表。**綠色免安裝，無需管理員權限**，為用戶提供流暢便捷的中文輸入體驗。

## ✨ 主要特色

### 🎯 雙模式輸入
- **中文筆劃模式**：使用五種基本筆劃（一丨丿丶フ）進行中文輸入
- **英文直接模式**：英文字母直接輸出，無需選字，最高效率
- **一鍵切換**：Shift鍵快速切換模式，無干擾輸入體驗

### 🔧 智能功能
- ✅ **最少字碼優先**：短字碼字符優先顯示
- ✅ **智能排序**：結合字碼長度和使用頻率
- ✅ **用戶學習**：自動記錄使用習慣，提升輸入效率
- ✅ **候選翻頁**：支援↑↓鍵翻頁選字
- ✅ **3+3模式**：支援*通配符搜尋


### 🎨 完全自訂介面
- 🎨 **完整配色方案**：支援主視窗和候選字視窗獨立配色
- 🖼️ **字體自訂**：主視窗和候選字可使用不同字體和大小
- 📐 **視窗大小調整**：可自訂主視窗和候選字視窗尺寸
- 🔄 **即時刷新**：配置更改即時生效，無需重啟
- 🖱️ **按鈕控制**：避免快捷鍵衝突的直觀按鈕介面
- 📱 **懸停效果**：現代化的界面交互體驗
- 🔄 **拖動支援**：主視窗和候選字視窗同步移動

### 📊 智能頻率學習系統
- 📈 **使用頻率統計**：自動記錄字詞選擇頻率
- ⏰ **時間權重衰減**：根據使用時間調整優先級  
- 💾 **漸進式記憶**：高頻詞彙自動加入永久詞庫


## 🚀 快速開始

### 系統要求

- **作業系統**：Windows 7 及以上版本
- **編譯環境**：MinGW (支援C++14)
- **依賴庫**：Windows API (gdi32, user32, comdlg32)
- **管理員權限**：安裝全域鍵盤鉤子需要

### 編譯安裝

克隆專案
git clone https://github.com/your-username/chinese-stroke-ime.git
cd chinese-stroke-ime

編譯程式
g++ -std=c++14 -DUNICODE -D_UNICODE -mwindows -O2 main.cpp -o ChineseStrokeIME.exe -luser32 -lgdi32 -lole32 -loleaut32 -static-libgcc -static-libstdc++ -Wl,--subsystem,windows

運行
./ChineseStrokeIME.exe



### 檔案結構

確保以下檔案與執行檔在同一目錄：

├── ChineseStrokeIME.exe
├── Zi-Ma-Biao.txt # 字碼表
├── interface_config.ini # 介面配置檔案
└── user_dict.txt # 用戶字典（自動生成）



## 🎛️ 配置系統

### interface_config.ini 設定檔

[Colors]

主視窗配色
background_color = #F5F5F5
text_color = #000000
error_color = #DC3232

按鈕配色
close_button_color = #DC3232
mode_button_color = #6432C8
credits_button_color = #C89632
refresh_button_color = #329632

候選字視窗專用配色
candidate_background_color = #FFFFFF
candidate_text_color = #000000
selected_candidate_background_color = #E6F0FA
selected_candidate_text_color = #0078D7

[Font]

主視窗字體
font_size = 16
font_name = Microsoft JhengHei

候選字字體
candidate_font_size = 18
candidate_font_name = Microsoft JhengHei

[Window]

視窗大小設定
window_width = 580
window_height = 70
candidate_width = 500
candidate_height = 320



## 📋 使用說明

### 基本操作

| 功能 | 操作方式 | 說明 |
|------|----------|------|
| 模式切換 | Shift鍵 / 紫色按鈕 | 中文筆劃 ↔ 英文直接輸入 |
| 製作人員 | 點擊橙色按鈕 | 顯示開發團隊信息 |
| 配置刷新 | 點擊綠色按鈕 | 重新載入所有配置檔案 |
| 關閉程式 | 點擊紅色按鈕 | 安全退出並保存設定 |

### 中文筆劃輸入

#### 基本筆劃對應

| 筆劃 | 按鍵 | Numpad | 說明 |
|------|------|--------|------|
| 一 (橫) | U | 7 | 橫劃 |
| 丨 (豎) | I | 8 | 豎劃 |
| 丿 (撇) | O | 9 | 撇劃 |
| 丶 (捺) | J | 4 | 捺劃/點 |
| フ (折) | K | 5 | 折劃 |
| * (通配符) | L | 0 | 通配符 |

#### 輸入示例

輸入 "oj" → 候選：人、入、八 (智能排序)
輸入 "uiojk" → 候選：更多複雜字符

🚀 (3+3)模式詳解
自動智能提示
當您輸入超過8個筆劃時，系統會自動顯示(3+3)建議：
實際輸入：uoikuuiuuikjjjj (「碼」字15筆劃)
系統提示：智慧排序搜尋：找到 X 個候選字 | 💡建議：uoi*jjj
狀態顯示：(3+3)模式搜尋：找到 Y 個候選字

手動通配符輸入
方法1：邊輸入邊使用：
步驟1：輸入頭三筆 → uoi
步驟2：按 L 鍵插入通配符 → uoi*
步驟3：輸入尾三筆 → uoi*jjj
結果：通配符元搜尋模式啟動

方法2：直接模式輸入
複雜字符：體 (23筆劃)
完整編碼：ikkjkikuuikuiiuuikujou
(3+3)編碼：ikk*jou
效率提升：70%

### 功能鍵操作

| 按鍵 | 功能 |
|------|------|
| **1-9** | 選擇對應候選字 |
| **↑↓** | 翻頁選字 |
| **退格** | 刪除最後一個字碼 |
| **ESC** | 清除當前輸入 |
| **P** | 開啟標點符號選單 |

### 標點符號系統

支援智能標點符號輸入

- **逗號**：, → ，（全形）/ ,（半形）
- **句號**：. → 。（全形）/ .（半形）
- **空格**：始終輸出半形空格
- **其他**：()[]?!:; 等支援全形/半形切換

## 🏗️ 技術架構

### 核心模組

// 主要組件
├── 全域鍵盤鉤子 // Low-level鍵盤事件攔截
├── 字典管理系統 // 高效中文字典載入與查詢
├── 智能排序引擎 // 頻率+長度+時間權重算法
├── 用戶學習模組 // 自適應頻率統計與上下文學習
├── 介面渲染引擎 // Windows GDI雙視窗繪製
├── 配置管理系統 // INI檔案解析與即時載入
└── 狀態管理中心 // 模式切換與狀態維護


### 關鍵特性

- **零外部依賴**：純Windows API實現
- **記憶體最佳化**：智能字典載入與快取機制
- **毫秒級響應**：優化的按鍵處理管線
- **異常安全**：完善的錯誤處理與資源管理
- **向下兼容**：支援Windows 7+所有版本
- **自訂深度**：從配色到字體的全方位個人化

### 性能優化

- **字典壓縮**：高效的字典儲存與查找算法
- **批量處理**：候選字批量排序，減少計算開銷
- **快取策略**：智能快取常用字詞，提升響應速度
- **資源池**：GDI資源重用，避免頻繁創建銷毀




## 🆕 版本 6.0 新功能

### 🎨 完整介面自訂系統
- **候選字視窗獨立配色**：背景色、文字色、選中狀態完全可配置
- **WM_ERASEBKGND 最佳化**：解決系統背景繪製衝突問題
- **字體系統分離**：主視窗和候選字視窗可使用不同字體

### 🧠 智慧標點符號過濾
- **自動識別標點符號**：支援中英文標點符號完整字元集
- **詞庫純淨化**：避免標點符號污染用戶字典
- **向下兼容**：現有字典檔案無影響

### ⚡ 配置系統增強
- **即時刷新功能**：配置更改無需重啟即可生效
- **全功能刷新按鈕**：一鍵重新載入所有配置和字典
- **錯誤容錯機制**：配置檔案錯誤時使用預設值

## 🤝 貢獻指南

歡迎提交Issue和Pull Request來改善本專案！

### 開發環境設置

1. 安裝MinGW編譯環境
2. 確保支援C++14標準
3. 配置Windows開發工具
4. 準備測試字典檔案

### 提交規範

- 遵循[Conventional Commits](https://www.conventionalcommits.org/)規範
- 提供清晰的commit message
- 包含適當的測試案例
- 確保向下兼容性

### 代碼風格

- 使用4空格縮進
- 函數名稱使用snake_case
- 類別名稱使用PascalCase
- 註釋使用繁體中文

## 📄 開源許可

本專案採用MIT許可證 - 查看[LICENSE](LICENSE)文件了解詳情。

## 👥 製作團隊

| 角色 | 貢獻者 | 說明 |
|------|--------|------|
| **編寫員** | Perplexity.ai | 核心算法設計與程式開發 |
| **測試員** | 山崎大叔（人類） | 功能測試與用戶體驗優化 |
| **技術顧問** | 開源社群 | 代碼審查與建議回饋 |

## 🔗 相關資源

- [Windows API開發文檔](https://docs.microsoft.com/en-us/windows/win32/)
- [Unicode字符編碼標準](https://unicode.org/)
- [中文輸入法技術規範](https://www.microsoft.com/typography/)
- [六碼筆畫輸入法參考](http://www.miniapps.hk/g6code/)



---

**重要提醒**：
- 可自訂 `Zi-Ma-Biao.txt`、`user_dict.txt` 檔案，建議定期備份
- 配置檔案支援即時修改，修改後點擊刷新按鈕即可生效

⭐ 如果這個專案對您有幫助，請給我們一個星標！

![GitHub stars](https://img.shields.io/github/stars/your-username/chinese-stroke-ime?style=social)
![GitHub forks](https://img.shields.io/github/forks/your-username/chinese-stroke-ime?style=social)
![GitHub issues](https://img.shields.io/github/issues/your-username/chinese-stroke-ime)
PS：山崎大叔（人類）未開設GitHub 


